<?php
$server ="den1.mysql4.gear.host";
$username = "usuario3";
$password = "chimi67.";
$database = "usuario3";

//conexion
$db = mysqli_connect($server,$username,$password,$database);

?>